# Java Automation Practice – Day 1

This folder contains the Day 1 code:
- `HelloWorld.java` – prints Hello World.

## How to compile & run (command line)

```bash
# Compile
javac HelloWorld.java

# Run
java HelloWorld
```
